import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class CheckTopological {
	public static void main(String args[]) throws FileNotFoundException {
		final Scanner testIn = new Scanner(new File(args[0]));

		final List<SEdge> orderings = new LinkedList<SEdge>();

		final int n = Integer.parseInt(testIn.nextLine());
		for (int i = 0; i < n; i++) {
			final String test1 = testIn.nextLine();
			System.out.println(test1);
			final String[] line = test1.split(" -> ");
			final SEdge edge = new SEdge(line[0], line[1]);
			orderings.add(edge);
		}

		testIn.close();

		final Scanner testAns = new Scanner(new File(args[1]));
		final Scanner result = new Scanner(System.in);

		if (testAns.nextLine().equals("IMPOSSIBLE!")) {
			if (result.nextLine().equals("IMPOSSIBLE!")) {
				testAns.close();
				result.close();
				System.exit(42);
			} else {
				final PrintWriter feedback = new PrintWriter(args[2]
						+ "judgemessage.txt");
				feedback.println("No valid solution");
				feedback.close();
				testAns.close();
				result.close();
				System.exit(43);
			}
		}

		testAns.close();

		final List<String> sort = Arrays
				.asList(result.nextLine().split(" -> "));

		result.close();

		for (final SEdge edge : orderings) {
			final String parent = edge.parent;
			final String child = edge.child;
			final int parentI = sort.indexOf(parent);
			final int childI = sort.indexOf(child);
			if (parentI == -1 || childI == -1 || childI < parentI) {
				final PrintWriter feedback = new PrintWriter(args[2]
						+ "judgemessage.txt");
				feedback.println("Constraint failed: " + parent + " -> "
						+ child);
				feedback.close();
				System.exit(43);
			}
		}

		System.exit(42);
	}
}

class SEdge {
	public String parent;
	public String child;

	public SEdge(String line, String line2) {
		parent = line;
		child = line2;
	}
}
